<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>extension_oswebext</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="28" />
        <source>Experiment started in external browser</source>
        <translation>Experimento iniciado em navegador externo</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Save as…</source>
        <translation>Salvar como..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>OSWeb and JATOS control panel</source>
        <translation>Painel de controle do OSWeb e JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Create online experiments</source>
        <translation>Criar experimentos online</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Open from MindProbe</source>
        <translation>Abrir do MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Open from JATOS</source>
        <translation>Abrir do JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="29" />
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Experiment has been published to JATOS</source>
        <translation>O experimento foi publicado no JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="30" />
        <source>Select OSWeb results file…</source>
        <translation>Selecione o arquivo de resultados do OSWeb…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Browse</source>
        <translation>Navegar</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>You have changed the name of the experiment. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Você mudou o nome do experimento. Você também quer desvincular o experimento do JATOS (redefinindo o UUID) para que você possa criar um novo experimento remoto?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Save and publish to JATOS</source>
        <translation>Salvar e publicar em JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>Unlink from JATOS</source>
        <translation>Desvincular do JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Save and publish to MindProbe</source>
        <translation>Salvar e publicar em MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>You have saved the experiment under a different file name. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Você salvou o experimento sob um nome de arquivo diferente. Você também quer desvincular o experimento do JATOS (redefinindo o UUID) para que você possa criar um novo experimento remoto?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Downloading …</source>
        <translation>Baixando ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>Uploading …</source>
        <translation>Enviando ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Hide</source>
        <translation>Esconder</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="31" />
        <source>Please wait …</source>
        <translation>Por favor, espere ..</translation>
    </message>
</context>
<context>
    <name>osweb_control_panel</name>
    <message>
        <location filename="../osweb_control_panel.ui" line="14" />
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="65" />
        <source>ICON</source>
        <translation>ÍCONE</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="136" />
        <source>Actions</source>
        <translation>Ações</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="181" />
        <source>Experiment properties</source>
        <translation>Propriedades do experimento</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="199" />
        <source>&lt;small  style="color:#78909c"&gt;Select OSWeb backend to run in browser&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Selecione o backend do OSWeb para executar no navegador&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="215" />
        <source>Open from JATOS</source>
        <translation>Abrir do JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="227" />
        <source>&lt;small  style="color:#78909c"&gt;Download experiment directly from JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Baixe o experimento diretamente do JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="265" />
        <source>Convert OSWeb results to .csv/ .xlsx</source>
        <translation>Converter resultados OSWeb para .csv/ .xlsx</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="277" />
        <source>&lt;small  style="color:#78909c"&gt;Convert JATOS result file to spreadsheet format&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Converta o arquivo de resultado JATOS para o formato de planilha&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="305" />
        <source>Import from JATOS archive</source>
        <translation>Importar do arquivo JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="318" />
        <source>Export to JATOS archive</source>
        <translation>Exportar para o arquivo JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="331" />
        <source>Export to HTML</source>
        <translation>Exportar para HTML</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="343" />
        <source>&lt;small  style="color:#78909c"&gt;Open experiment from jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Abra o experimento a partir do arquivo jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="355" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Salve o experimento como arquivo jzip&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="367" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as standalone html file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Salve o experimento como um arquivo html autônomo&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="78" />
        <source>&lt;b&gt;OSWeb and JATOS control panel&lt;/b&gt;&lt;br /&gt;Options for online experiments and JATOS synchronization</source>
        <translation>&lt;b&gt;OSWeb e painel de controle JATOS&lt;/b&gt;&lt;br /&gt;Opções para experimentos online e sincronização JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="240" />
        <source>Save and publish to JATOS</source>
        <translation>Salvar e publicar em JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="252" />
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Save experiment and upload directly to JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Salvar o experimento e fazer o upload diretamente para o JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="126" />
        <source>&lt;h2 style="color:#78909c"&gt;To publish experiments directly to JATOS, please specify a server and API token below&lt;/h2&gt;</source>
        <translation>&lt;h2 style="color:#78909c"&gt;Para publicar experiências diretamente para JATOS, por favor especifique um servidor e token API abaixo&lt;/h2&gt;</translation>
    </message>
</context>
<context>
    <name>plugin_inline_html</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Embeds custom HTML</source>
        <translation>Incorpora HTML personalizado</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>An HTML editor widget</source>
        <translation>Um widget de editor HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>HTML editor</source>
        <translation>Editor de HTML</translation>
    </message>
</context>
<context>
    <name>plugin_inline_javascript</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Executes JavaScript code</source>
        <translation>Executa código JavaScript</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../preferences.ui" line="14" />
        <source>Form</source>
        <translation>Formulário</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="125" />
        <source>Possible subject numbers</source>
        <translation>Possíveis números de sujeitos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182" />
        <source>&lt;small  style="color:#78909c"&gt;Run experiment even if compatibility check fails&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Execute o experimento mesmo se a verificação de compatibilidade falhar&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="194" />
        <source>&lt;small style="color:#78909c"&gt;Appears on OSWeb welcome screen.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Aparece na tela de boas-vindas do OSWeb.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103" />
        <source>Show OSWeb welcome screen</source>
        <translation>Mostrar tela de boas-vindas do OSWeb</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="209" />
        <source>&lt;small  style="color:#78909c"&gt;Loaded when experiment starts&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Carregado quando o experimento começa&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="135" />
        <source>Bypass compatibility check</source>
        <translation>Ignorar a verificação de compatibilidade</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="142" />
        <source>Welcome text</source>
        <translation>Texto de boas-vindas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="118" />
        <source>&lt;small  style="color:#78909c"&gt;Only applies when exporting&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Aplica-se apenas ao exportar&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="84" />
        <source>Never provide personal or sensitive information such as credit card numbers or PIN codes. Click or touch the screen to begin!</source>
        <translation>Nunca forneça informações pessoais ou sensíveis, como números de cartão de crédito ou códigos PIN. Clique ou toque na tela para começar!</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219" />
        <source>0,1</source>
        <translation>0,1</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="71" />
        <source>One URL per line</source>
        <translation>Um URL por linha</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="167" />
        <source>External libraries</source>
        <translation>Bibliotecas externas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="238" />
        <source>&lt;small  style="color:#78909c"&gt;Required for reliable media playback&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Necessário para reprodução de mídia confiável&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="226" />
        <source>Make browser fullscreen</source>
        <translation>Tornar navegador em tela cheia</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="305" />
        <source>JATOS UUID</source>
        <translation>UUID do JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="415" />
        <source>&lt;small  style="color:#78909c"&gt;Visit &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; to request a free account&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Visite &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; para solicitar uma conta gratuita&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="387" />
        <source>JATOS server</source>
        <translation>Servidor JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="435" />
        <source>jap_</source>
        <translation>jap_</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="403" />
        <source>https://jatos.mindprobe.eu</source>
        <translation>https://jatos.mindprobe.eu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="330" />
        <source>&lt;small  style="color:#78909c"&gt;Identifies experiment on JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Identifica experimento no JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="318" />
        <source>undefined</source>
        <translation>indefinido</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="422" />
        <source>JATOS API token</source>
        <translation>Token da API do JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="447" />
        <source>&lt;small  style="color:#78909c"&gt;Available from JATOS user profile&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Disponível do perfil do usuário JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="337" />
        <source>Clear UUID</source>
        <translation>Limpar UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="353" />
        <source>&lt;small  style="color:#78909c"&gt;Resets link between experiment and JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Redefine a ligação entre o experimento e o JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245" />
        <source>Apply background color to full browser tab</source>
        <translation>Aplicar cor de fundo à aba completa do navegador</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="460" />
        <source>Ignore conflicts</source>
        <translation>Ignorar conflitos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="472" />
        <source>&lt;small  style="color:#78909c"&gt;Overwrites conflicting files when publishing. This option is automatically reset.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Sobrescreve arquivos conflitantes ao publicar. Essa opção é redefinida automaticamente.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41" />
        <source>OSWeb: Configure how the experiment runs in the browser</source>
        <translation>OSWeb: Configure como o experimento é executado no navegador</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="157" />
        <source>&lt;small  style="color:#78909c"&gt;OSWeb is a JavaScript library for running OpenSesame experiments in a web browser.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;OSWeb é uma biblioteca JavaScript para executar experimentos OpenSesame em um navegador da web.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="261" />
        <source>JATOS: Configure experiment properties on the server</source>
        <translation>JATOS: Configure as propriedades do experimento no servidor</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="279" />
        <source>JATOS end-redirect URL</source>
        <translation>URL de redirecionamento final do JATOS</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="286" />
        <source>https://</source>
        <translation>https://</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="298" />
        <source>&lt;small  style="color:#78909c"&gt;Notifies participant platform (Sona Systems, Prolific, etc.) when experiment finishes&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;Notifica a plataforma do participante (Sona Systems, Prolific, etc.) quando o experimento termina&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="369" />
        <source>JATOS: Configure the server</source>
        <translation>JATOS: Configure o servidor</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="484" />
        <source>&lt;small  style="color:#78909c"&gt;JATOS is server software for managing online experiments. You need an account on a JATOS server, such as mindprobe.eu, to run experiments online. You need to enter a JATOS API token to connect OpenSesame to JATOS. Visit the OpenSesame documentation for instructions.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;JATOS é um software de servidor para gerenciar experimentos online. Você precisa de uma conta em um servidor JATOS, como mindprobe.eu, para executar experimentos online. Você precisa inserir um token de API do JATOS para conectar o OpenSesame ao JATOS. Visite a documentação do OpenSesame para instruções.&lt;/small&gt;</translation>
    </message>
</context>
</TS>