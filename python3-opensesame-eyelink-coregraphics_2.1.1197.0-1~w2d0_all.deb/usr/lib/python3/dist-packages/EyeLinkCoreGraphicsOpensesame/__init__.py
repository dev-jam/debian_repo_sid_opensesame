import importlib.metadata
__version__ = importlib.metadata.version("opensesame-eyelink-coregraphics")
_last_updated = '09/06/2024'

from .EyeLinkCoreGraphicsOpensesame import EyeLinkCoreGraphicsOpensesame
