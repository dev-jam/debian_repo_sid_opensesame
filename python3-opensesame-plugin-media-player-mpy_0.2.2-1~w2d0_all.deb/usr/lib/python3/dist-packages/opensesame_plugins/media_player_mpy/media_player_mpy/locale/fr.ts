<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_media_player_mpy</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Media player based on moviepy</source>
        <translation>Lecteur multimédia basé sur moviepy</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Play audio</source>
        <translation>Jouer l'audio</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Custom Python code (See Help for more information)</source>
        <translation>Code Python personnalisé (Voir Aide pour plus d'informations)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Duration</source>
        <translation>Durée</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Fit video to screen</source>
        <translation>Adapter la vidéo à l'écran</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Restart the video after it ends</source>
        <translation>Redémarrer la vidéo après qu'elle se termine</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Specify how you would like to handle events like mouse clicks or keypresses. When set, this overrides the Duration attribute</source>
        <translation>Précisez comment vous souhaitez gérer des événements tels que les clics de souris ou les pressions de touches. Lorsqu'il est défini, cela remplace l'attribut Durée</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Video file</source>
        <translation>Fichier vidéo</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>Maintains the aspect ratio</source>
        <translation>Maintient le rapport d'aspect</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Call custom Python code</source>
        <translation>Appeler du code Python personnalisé</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>When to call custom event handling code (if any)</source>
        <translation>Quand appeler du code de gestion d'événement personnalisé (le cas échéant)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>The library to use for sound rendering (recommended: sounddevice)</source>
        <translation>La bibliothèque à utiliser pour le rendu sonore (recommandé : sounddevice)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>&lt;small&gt;&lt;b&gt;Media Player OpenSesame Plugin, Copyright (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</source>
        <translation>&lt;small&gt;&lt;b&gt;Media Player Plugin OpenSesame, Droits d'auteur (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Loop</source>
        <translation>Boucle</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Sound renderer</source>
        <translation>Rendu sonore</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Visual stimuli</source>
        <translation>Stimuli visuels</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>A value in milliseconds, 'sound', 'mouseclick', or 'keypress'</source>
        <translation>Une valeur en millisecondes, 'sound', 'mouseclick', ou 'keypress'</translation>
    </message>
</context>
</TS>