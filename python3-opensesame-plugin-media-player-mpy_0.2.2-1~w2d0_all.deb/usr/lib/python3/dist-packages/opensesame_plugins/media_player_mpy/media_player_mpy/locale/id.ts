<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_media_player_mpy</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Media player based on moviepy</source>
        <translation>Pemutar media berbasis moviepy</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Play audio</source>
        <translation>Putar audio</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Custom Python code (See Help for more information)</source>
        <translation>Kode Python khusus (Lihat Bantuan untuk informasi lebih lanjut)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Duration</source>
        <translation>Durasi</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Fit video to screen</source>
        <translation>Sesuaikan video ke layar</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Restart the video after it ends</source>
        <translation>Mulai ulang video setelah selesai</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Specify how you would like to handle events like mouse clicks or keypresses. When set, this overrides the Duration attribute</source>
        <translation>Tentukan bagaimana Anda ingin menangani event seperti klik mouse atau tekan tombol. Jika diatur, ini akan menimpa atribut Durasi</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Video file</source>
        <translation>File video</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>Maintains the aspect ratio</source>
        <translation>Menjaga rasio aspek</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Call custom Python code</source>
        <translation>Memanggil kode Python khusus</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>When to call custom event handling code (if any)</source>
        <translation>Kapan memanggil kode penanganan event khusus (jika ada)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>The library to use for sound rendering (recommended: sounddevice)</source>
        <translation>Perpustakaan yang digunakan untuk rendering suara (disarankan: sounddevice)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>&lt;small&gt;&lt;b&gt;Media Player OpenSesame Plugin, Copyright (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</source>
        <translation>&lt;small&gt;&lt;b&gt;Media Player Plugin OpenSesame, Hak Cipta (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Loop</source>
        <translation>Loop</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Sound renderer</source>
        <translation>Penggambar suara</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Visual stimuli</source>
        <translation>Stimuli visual</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>A value in milliseconds, 'sound', 'mouseclick', or 'keypress'</source>
        <translation>Nilai dalam milidetik, 'sound', 'mouseclick', atau 'keypress'</translation>
    </message>
</context>
</TS>