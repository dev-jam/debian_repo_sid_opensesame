<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_media_player_mpy</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Media player based on moviepy</source>
        <translation>Reproductor de medios basado en moviepy</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Play audio</source>
        <translation>Reproducir audio</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Custom Python code (See Help for more information)</source>
        <translation>Código Python personalizado (Ver Ayuda para más información)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Duration</source>
        <translation>Duración</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Fit video to screen</source>
        <translation>Ajustar video a la pantalla</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Restart the video after it ends</source>
        <translation>Reiniciar el video después de que termine</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Specify how you would like to handle events like mouse clicks or keypresses. When set, this overrides the Duration attribute</source>
        <translation>Especifique cómo desea manejar eventos como clics de ratón o pulsaciones de teclas. Cuando se establece, esto anula el atributo Duración</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Video file</source>
        <translation>Archivo de vídeo</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>Maintains the aspect ratio</source>
        <translation>Mantiene la relación de aspecto</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Call custom Python code</source>
        <translation>Llamar código Python personalizado</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>When to call custom event handling code (if any)</source>
        <translation>Cuándo llamar a código de manejo de eventos personalizado (si lo hay)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>The library to use for sound rendering (recommended: sounddevice)</source>
        <translation>La biblioteca a utilizar para la renderización de sonido (recomendado: sounddevice)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>&lt;small&gt;&lt;b&gt;Media Player OpenSesame Plugin, Copyright (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</source>
        <translation>&lt;small&gt;&lt;b&gt;Media Player Plugin OpenSesame, Derechos de autor (2015-2023) Daniel Schreij&lt;/b&gt;&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Loop</source>
        <translation>Bucle</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Sound renderer</source>
        <translation>Renderizador de sonido</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Visual stimuli</source>
        <translation>Estímulos visuales</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>A value in milliseconds, 'sound', 'mouseclick', or 'keypress'</source>
        <translation>Un valor en milisegundos, 'sound', 'mouseclick', o 'keypress'</translation>
    </message>
</context>
</TS>