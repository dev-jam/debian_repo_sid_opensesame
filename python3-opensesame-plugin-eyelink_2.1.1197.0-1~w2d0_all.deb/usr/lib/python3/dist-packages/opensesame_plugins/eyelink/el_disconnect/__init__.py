category = 'EyeLink'
version = 1.0
author: 'Jono Batten' 'Zhiguo Wang'
url = 'http://www.sr-research.com'
priority = 9
controls = [
{'type': 'text',
 'label': '<b>Close the link and retrieve the data file</b> <br /><br />This node will help to close the link to the tracker and retrieve the data from the Host PC.',
 'name': 'text_el_close_link'}
 ]