# Item: el_disconnect

This item will disconnect from the EyeLink Host PC and retrieve the EDF data file over the link. No option to configure for this item.