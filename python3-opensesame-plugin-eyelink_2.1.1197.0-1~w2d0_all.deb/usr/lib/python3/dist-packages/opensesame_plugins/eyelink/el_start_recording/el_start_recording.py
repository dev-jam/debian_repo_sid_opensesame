# -*- coding:utf-8 -*-
#
# Copyright (c) 1996-2024, SR Research Ltd., All Rights Reserved
#
# For use by SR Research licencees only. Redistribution and use in source
# and binary forms, with or without modification, are NOT permitted.
#
# Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in
# the documentation and/or other materials provided with the distribution.
#
# Neither name of SR Research Ltd nor the name of contributors may be used
# to endorse or promote products derived from this software without
# specific prior written permission.
#
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS
# IS'' AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
# TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
# PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
# EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
# PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
# PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
# LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
# SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#
# 2024
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or (at
# your option) any later version.
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
# for more details.
# You should have received a copy of the GNU General Public License along with
# this program; if not, write to the Free Software Foundation, Inc., 51
# Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

# Import Python 3 compatibility functions
from libopensesame.py3compat import *
from libopensesame.item import Item
from libqtopensesame.items.qtautoplugin import QtAutoPlugin
import pylink


class ElStartRecording(Item):
    # Provide an informative description for your plug-in.
    description = u'Start data recording'

    def __init__(self, name, experiment, string=None):
        super().__init__(name, experiment, string)

    def reset(self):

        """ desc: Resets plug-in to initial values. """

        # Here we provide default values for the variables that are specified
        # in __init__.py
        self.var.el_link_data_events = u'yes'
        self.var.el_link_data_samples = u'yes'
        self.var.el_recording_status_msg = u''


    def run(self):
        """The run phase of the plug-in goes here."""
        link_events = 0
        link_samples = 0
        file_events = 1
        file_samples = 1
        if self.var.el_link_data_events == u'yes':
            link_events = 1
        if self.var.el_link_data_samples == u'yes':
            link_samples = 1

        if self.experiment.dummy_mode is False:
            # we first send a keyword message to the tracker to mark the start of a new trial
            self.experiment.eyelink.sendMessage('TRIALID')

            # send a recording status message to the tracker.
            if len(self.var.el_recording_status_msg) > 0:
                self.experiment.eyelink.sendCommand("record_status_message '%s'" % self.var.el_recording_status_msg)

            # start recording and specify what data is saved in file and what data are available over link
            self.experiment.eyelink.startRecording(file_samples, file_events, link_samples, link_events)
            pylink.pumpDelay(100)  # wait for 100 msec to allow the tracker to buffer some samples
        else:
            pass
        print(self.var.el_recording_status_msg)


class QtElStartRecording(ElStartRecording, QtAutoPlugin):

    """ This class handles the GUI aspect of the plug-in. By using qtautoplugin, we
    usually need to do hardly anything, because the GUI is defined in info.json. """

    def __init__(self, name, experiment, script=None):

        # We don't need to do anything here, except call the parent
        # constructors.
        ElStartRecording.__init__(self, name, experiment, script)
        QtAutoPlugin.__init__(self, __file__)

    def init_edit_widget(self):
        super().init_edit_widget()