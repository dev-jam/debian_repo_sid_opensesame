# Item: el_stop_recording

This item is usually placed at the end of a trial to stop the recording of eye movement data, and to do some housekeeping work. 
It should be noted that all experimental and trial variables available in the OpenSesame namespace can be selected and sent to the tracker by this node.