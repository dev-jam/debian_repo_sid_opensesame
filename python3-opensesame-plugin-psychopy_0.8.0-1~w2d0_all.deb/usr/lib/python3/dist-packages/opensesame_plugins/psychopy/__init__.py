"""PsychoPy plugins for OpenSesame"""

# The name of the packages to check for updates on conda and pip
packages = ['opensesame-plugin-psychopy']
