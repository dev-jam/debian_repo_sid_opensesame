<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_psychopy_textstim</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Opacity</source>
        <translation>Transparenz</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Drawing order</source>
        <translation>Zeichenreihenfolge</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Custom Python code</source>
        <translation>Angepasster Python-Code</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>A valid PsychoPy color argument</source>
        <translation>Ein gültiges PsychoPy-Farbenargument</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Vertical position (y)</source>
        <translation>Vertikale Position (y)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Interpret values as</source>
        <translation>Werte interpretieren als</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Positive is up!</source>
        <translation>Positiv ist auf!</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Font size</source>
        <translation>Schriftgröße</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>-1 = no updating</source>
        <translation>-1 = kein Updating</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>0 is fully transparent, 1 is fully opaque</source>
        <translation>0 ist vollständig transparent, 1 ist vollständig undurchsichtig</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Font family</source>
        <translation>Schriftfamilie</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Visual stimuli</source>
        <translation>Visuelle Reize</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>A PsychoPy TextStim, mainly for use with coroutines</source>
        <translation />
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>0 is no contrast, 1 is full contrast</source>
        <translation>0 bedeutet kein Kontrast, 1 bedeutet voller Kontrast</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Lowest values draw first</source>
        <translation>Niedrigste Werte werden zuerst gezeichnet</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Text</source>
        <translation>Text</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Color</source>
        <translation>Farbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>In degrees of clockwise rotation from vertical</source>
        <translation>In Grad der im Uhrzeigersinn erfolgenden Drehung von der Vertikalen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Object name</source>
        <translation>Objektname</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>For Python script</source>
        <translation>Für Python-Skript</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>Update every</source>
        <translation>Aktualisieren Sie jeden</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Horizontal position (x)</source>
        <translation>Horizontale Position (x)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Orientation</source>
        <translation>Orientierung</translation>
    </message>
</context>
</TS>