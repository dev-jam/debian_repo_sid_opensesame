<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_psychopy_textstim</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Opacity</source>
        <translation>Opacidade</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Drawing order</source>
        <translation>Ordem de desenho</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Custom Python code</source>
        <translation>Código Python personalizado</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>A valid PsychoPy color argument</source>
        <translation>Um argumento de cor PsychoPy válido</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Vertical position (y)</source>
        <translation>Posição vertical (y)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Interpret values as</source>
        <translation>Interpretar valores como</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Positive is up!</source>
        <translation>Positivo está para cima!</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Font size</source>
        <translation>Tamanho da fonte</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>-1 = no updating</source>
        <translation>-1 = sem atualização</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>0 is fully transparent, 1 is fully opaque</source>
        <translation>0 é totalmente transparente, 1 é totalmente opaco</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Font family</source>
        <translation>Família de fontes</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Visual stimuli</source>
        <translation>Estímulos visuais</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>A PsychoPy TextStim, mainly for use with coroutines</source>
        <translation>Um PsychoPy TextStim, principalmente para uso com coroutines</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>0 is no contrast, 1 is full contrast</source>
        <translation>0 é sem contraste, 1 é contraste total</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Lowest values draw first</source>
        <translation>Valores mais baixos desenham primeiro</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Text</source>
        <translation>Texto</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Color</source>
        <translation>Cor</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>In degrees of clockwise rotation from vertical</source>
        <translation>Em graus de rotação no sentido horário a partir do vertical</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Object name</source>
        <translation>Nome do objeto</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>For Python script</source>
        <translation>Para script Python</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>Update every</source>
        <translation>Atualize a cada</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Contrast</source>
        <translation>Contraste</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Horizontal position (x)</source>
        <translation>Posição horizontal (x)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Orientation</source>
        <translation>Orientação</translation>
    </message>
</context>
</TS>