<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_psychopy_gratingstim</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>Phase</source>
        <translation>Aşama</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>A PsychoPy GratingStim, mainly for use with coroutines</source>
        <translation>PsychoPy'nin GratingStim'i, çoğunlukla coroutines ile kullanım için</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>In degrees of clockwise rotation from vertical</source>
        <translation>Dikeyden saat yönünde dönüşün dereceleri olarak</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Interpret values as</source>
        <translation>Değerleri şu şekilde yorumlayın</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Update every</source>
        <translation>Her güncelleme</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>A valid PsychoPy tex argument</source>
        <translation>Geçerli bir PsychoPy tex argümanı</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="32" />
        <source>Vertical position (y)</source>
        <translation>Dikey pozisyon (y)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="33" />
        <source>0 is fully transparent, 1 is fully opaque</source>
        <translation>0 tamamen şeffaf, 1 tamamen opaktır</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="28" />
        <source>-1 = no updating</source>
        <translation>-1 = güncelleme yok</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Opacity</source>
        <translation>Opaklık</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Height</source>
        <translation>Yükseklik</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="29" />
        <source>Spatial frequency</source>
        <translation>Mekansal frekans</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Custom Python code</source>
        <translation>Özel Python kodu</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>Color</source>
        <translation>Renk</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Width</source>
        <translation>Genişlik</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>Drawing order</source>
        <translation>Çizim sırası</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="30" />
        <source>Object name</source>
        <translation>Nesne adı</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="31" />
        <source>Between 0 and 1</source>
        <translation>0 ve 1 arasında</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>For Python script</source>
        <translation>Python betiği için</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>0 is no contrast, 1 is full contrast</source>
        <translation>0 kontrast yok, 1 tam kontrast</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>A valid PsychoPy color argument</source>
        <translation>Geçerli bir PsychoPy renk argümanı</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>A valid PsychoPy mask argument</source>
        <translation>Geçerli bir PsychoPy maske argümanı</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Lowest values draw first</source>
        <translation>En düşük değerler ilk çizilir</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Texture</source>
        <translation>Doku</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>Orientation</source>
        <translation>Yönlendirme</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Cycles per pixel</source>
        <translation>Piksel başına döngüler</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>Horizontal position (x)</source>
        <translation>Yatay pozisyon (x)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>Visual stimuli</source>
        <translation>Görsel uyarıcılar</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>Mask</source>
        <translation>Maske</translation>
    </message>
</context>
</TS>