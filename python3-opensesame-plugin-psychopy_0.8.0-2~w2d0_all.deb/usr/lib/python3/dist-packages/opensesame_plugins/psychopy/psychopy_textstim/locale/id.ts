<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_psychopy_textstim</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Opacity</source>
        <translation>Keburaman</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Drawing order</source>
        <translation>Urutan menggambar</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Custom Python code</source>
        <translation>Kode Python khusus</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>A valid PsychoPy color argument</source>
        <translation>Argumen warna PsychoPy yang valid</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Vertical position (y)</source>
        <translation>Posisi vertikal (y)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Interpret values as</source>
        <translation>Menginterprestasikan nilai sebagai</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Positive is up!</source>
        <translation>Positif adalah ke atas!</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Font size</source>
        <translation>Ukuran font</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>-1 = no updating</source>
        <translation>-1 = tidak ada pembaruan</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>0 is fully transparent, 1 is fully opaque</source>
        <translation>0 sepenuhnya transparan, 1 sepenuhnya tidak tembus pandang</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Font family</source>
        <translation>Keluarga font</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Visual stimuli</source>
        <translation>Stimuli visual</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>A PsychoPy TextStim, mainly for use with coroutines</source>
        <translation>Sebuah TextStim PsychoPy, terutama untuk digunakan dengan coroutines</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>0 is no contrast, 1 is full contrast</source>
        <translation>0 adalah tanpa kontras, 1 adalah kontras penuh</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Lowest values draw first</source>
        <translation>Nilai terendah menggambar pertama</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Text</source>
        <translation>Teks</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Color</source>
        <translation>Warna</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>In degrees of clockwise rotation from vertical</source>
        <translation>Dalam derajat rotasi searah jarum jam dari vertikal</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Object name</source>
        <translation>Nama objek</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>For Python script</source>
        <translation>Untuk skrip Python</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>Update every</source>
        <translation>Perbarui setiap</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Contrast</source>
        <translation>Kontras</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Horizontal position (x)</source>
        <translation>Posisi horizontal (x)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Orientation</source>
        <translation>Orientasi</translation>
    </message>
</context>
</TS>