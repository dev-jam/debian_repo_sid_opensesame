<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>plugin_psychopy_textstim</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>Opacity</source>
        <translation>Opaklık</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Drawing order</source>
        <translation>Çizim sırası</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>Custom Python code</source>
        <translation>Özel Python kodu</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>A valid PsychoPy color argument</source>
        <translation>Geçerli bir PsychoPy renk argümanı</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="7" />
        <source>Vertical position (y)</source>
        <translation>Dikey pozisyon (y)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="8" />
        <source>Interpret values as</source>
        <translation>Değerleri şu şekilde yorumlayın</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Positive is up!</source>
        <translation>Pozitif yukarıda!</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>Font size</source>
        <translation>Yazı tipi boyutu</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="11" />
        <source>-1 = no updating</source>
        <translation>-1 = güncelleme yok</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="12" />
        <source>0 is fully transparent, 1 is fully opaque</source>
        <translation>0 tamamen şeffaf, 1 tamamen opaktır</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Font family</source>
        <translation>Yazı tipi ailesi</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>Visual stimuli</source>
        <translation>Görsel uyarıcılar</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>A PsychoPy TextStim, mainly for use with coroutines</source>
        <translation>PsychoPy'nin TextStim'i, özellikle coroutines ile kullanım için</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>0 is no contrast, 1 is full contrast</source>
        <translation>0 kontrast yok, 1 tam kontrast</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Lowest values draw first</source>
        <translation>En düşük değerler ilk çizilir</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Text</source>
        <translation>Metin</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source> ms</source>
        <translation> ms</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Color</source>
        <translation>Renk</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>In degrees of clockwise rotation from vertical</source>
        <translation>Dikeyden saat yönünde dönüşün dereceleri olarak</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Object name</source>
        <translation>Nesne adı</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>For Python script</source>
        <translation>Python betiği için</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>Update every</source>
        <translation>Her güncelleme</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Contrast</source>
        <translation>Kontrast</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Horizontal position (x)</source>
        <translation>Yatay pozisyon (x)</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Orientation</source>
        <translation>Yönlendirme</translation>
    </message>
</context>
</TS>