<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>extension_oswebext</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="28" />
        <source>Experiment started in external browser</source>
        <translation>在外部浏览器中启动了实验</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Save as…</source>
        <translation>另存为…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>OSWeb and JATOS control panel</source>
        <translation>OSWeb 和 JATOS 控制面板</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Create online experiments</source>
        <translation>创建在线实验</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Open from MindProbe</source>
        <translation>从 MindProbe 打开</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Open from JATOS</source>
        <translation>从 JATOS 打开</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="29" />
        <source>Open</source>
        <translation>打开</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Experiment has been published to JATOS</source>
        <translation>实验已发布到 JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="30" />
        <source>Select OSWeb results file…</source>
        <translation>选择 OSWeb 结果文件…</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Browse</source>
        <translation>浏览</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>You have changed the name of the experiment. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>你已经改变了实验的名字。你是否也想要取消与JATOS的链接（通过重置UUID），这样你就能够创建一个新的远程实验？</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Save and publish to JATOS</source>
        <translation>保存并发布到JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>Unlink from JATOS</source>
        <translation>解除与JATOS的链接</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Save and publish to MindProbe</source>
        <translation>保存并发布到MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>You have saved the experiment under a different file name. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>您已经以不同的文件名保存了实验。您是否也希望将实验与JATOS解除链接(通过重置UUID)，以便您可以创建一个新的远程实验？</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Downloading …</source>
        <translation>正在下载 ...</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>Uploading …</source>
        <translation>正在上传 ...</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Hide</source>
        <translation>隐藏</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="31" />
        <source>Please wait …</source>
        <translation>请等待 ...</translation>
    </message>
</context>
<context>
    <name>osweb_control_panel</name>
    <message>
        <location filename="../osweb_control_panel.ui" line="14" />
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="65" />
        <source>ICON</source>
        <translation>图标</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="136" />
        <source>Actions</source>
        <translation>操作</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="181" />
        <source>Experiment properties</source>
        <translation>实验属性</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="199" />
        <source>&lt;small  style="color:#78909c"&gt;Select OSWeb backend to run in browser&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;选择 OSWeb 后端在浏览器中运行&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="215" />
        <source>Open from JATOS</source>
        <translation>从 JATOS 打开</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="227" />
        <source>&lt;small  style="color:#78909c"&gt;Download experiment directly from JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;直接从 JATOS 下载实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="265" />
        <source>Convert OSWeb results to .csv/ .xlsx</source>
        <translation>将 OSWeb 结果转换为 .csv/ .xlsx</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="277" />
        <source>&lt;small  style="color:#78909c"&gt;Convert JATOS result file to spreadsheet format&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;将 JATOS 结果文件转换为电子表格格式&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="305" />
        <source>Import from JATOS archive</source>
        <translation>从 JATOS 存档导入</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="318" />
        <source>Export to JATOS archive</source>
        <translation>导出到 JATOS 存档</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="331" />
        <source>Export to HTML</source>
        <translation>导出为HTML</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="343" />
        <source>&lt;small  style="color:#78909c"&gt;Open experiment from jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;从 jzip 文件打开实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="355" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;将实验保存为 jzip 文件&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="367" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as standalone html file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;将实验保存为独立的 html 文件&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="78" />
        <source>&lt;b&gt;OSWeb and JATOS control panel&lt;/b&gt;&lt;br /&gt;Options for online experiments and JATOS synchronization</source>
        <translation>&lt;b&gt;OSWeb和JATOS控制面板&lt;/b&gt;&lt;br /&gt;在线实验和JATOS同步的选项</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="240" />
        <source>Save and publish to JATOS</source>
        <translation>保存并发布到JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="252" />
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Save experiment and upload directly to JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;保存实验并直接上传到JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="126" />
        <source>&lt;h2 style="color:#78909c"&gt;To publish experiments directly to JATOS, please specify a server and API token below&lt;/h2&gt;</source>
        <translation>&lt;h2 style="color:#78909c"&gt;要直接将实验发布到 JATOS，请在下面指定服务器和API令牌&lt;/h2&gt;</translation>
    </message>
</context>
<context>
    <name>plugin_inline_html</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Embeds custom HTML</source>
        <translation>嵌入自定义 HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>An HTML editor widget</source>
        <translation>一个HTML编辑器小部件</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>HTML editor</source>
        <translation>HTML 编辑器</translation>
    </message>
</context>
<context>
    <name>plugin_inline_javascript</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Executes JavaScript code</source>
        <translation>执行 JavaScript 代码</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../preferences.ui" line="14" />
        <source>Form</source>
        <translation>表单</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="125" />
        <source>Possible subject numbers</source>
        <translation>可能的被试编号</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182" />
        <source>&lt;small  style="color:#78909c"&gt;Run experiment even if compatibility check fails&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;即使兼容性检查失败也运行实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="194" />
        <source>&lt;small style="color:#78909c"&gt;Appears on OSWeb welcome screen.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;出现在 OSWeb 欢迎屏幕上。&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103" />
        <source>Show OSWeb welcome screen</source>
        <translation>显示 OSWeb 欢迎屏幕</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="209" />
        <source>&lt;small  style="color:#78909c"&gt;Loaded when experiment starts&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;实验开始时加载&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="135" />
        <source>Bypass compatibility check</source>
        <translation>跳过兼容性检查</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="142" />
        <source>Welcome text</source>
        <translation>欢迎文字</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="118" />
        <source>&lt;small  style="color:#78909c"&gt;Only applies when exporting&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;只在导出时适用&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="84" />
        <source>Never provide personal or sensitive information such as credit card numbers or PIN codes. Click or touch the screen to begin!</source>
        <translation>切勿提供个人或敏感信息，如信用卡号或 PIN 码。点击或触摸屏幕开始！</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219" />
        <source>0,1</source>
        <translation>0,1</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="71" />
        <source>One URL per line</source>
        <translation>每行一个 URL</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="167" />
        <source>External libraries</source>
        <translation>外部库</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="238" />
        <source>&lt;small  style="color:#78909c"&gt;Required for reliable media playback&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;用于可靠的媒体播放&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="226" />
        <source>Make browser fullscreen</source>
        <translation>将浏览器设为全屏</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="305" />
        <source>JATOS UUID</source>
        <translation>JATOS UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="415" />
        <source>&lt;small  style="color:#78909c"&gt;Visit &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; to request a free account&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;访问&lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt;申请免费账户&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="387" />
        <source>JATOS server</source>
        <translation>JATOS 服务器</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="435" />
        <source>jap_</source>
        <translation>jap_</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="403" />
        <source>https://jatos.mindprobe.eu</source>
        <translation>https://jatos.mindprobe.eu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="330" />
        <source>&lt;small  style="color:#78909c"&gt;Identifies experiment on JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;在 JATOS 上标识实验&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="318" />
        <source>undefined</source>
        <translation>未定义</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="422" />
        <source>JATOS API token</source>
        <translation>JATOS API 令牌</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="447" />
        <source>&lt;small  style="color:#78909c"&gt;Available from JATOS user profile&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;来自JATOS用户配置文件&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="337" />
        <source>Clear UUID</source>
        <translation>清除 UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="353" />
        <source>&lt;small  style="color:#78909c"&gt;Resets link between experiment and JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;重置实验和 JATOS 之间的链接&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245" />
        <source>Apply background color to full browser tab</source>
        <translation>将背景色应用于整个浏览器标签页</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="460" />
        <source>Ignore conflicts</source>
        <translation>忽略冲突</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="472" />
        <source>&lt;small  style="color:#78909c"&gt;Overwrites conflicting files when publishing. This option is automatically reset.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;发布时覆盖冲突的文件。此选项会自动重置。&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41" />
        <source>OSWeb: Configure how the experiment runs in the browser</source>
        <translation>OSWeb: 配置实验在浏览器中的运行方式</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="157" />
        <source>&lt;small  style="color:#78909c"&gt;OSWeb is a JavaScript library for running OpenSesame experiments in a web browser.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;OSWeb 是一个 JavaScript 库，用于在 Web 浏览器中运行 OpenSesame 实验。&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="261" />
        <source>JATOS: Configure experiment properties on the server</source>
        <translation>JATOS: 配置服务器上的实验属性</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="279" />
        <source>JATOS end-redirect URL</source>
        <translation>JATOS 结束重定向 URL</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="286" />
        <source>https://</source>
        <translation>https://</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="298" />
        <source>&lt;small  style="color:#78909c"&gt;Notifies participant platform (Sona Systems, Prolific, etc.) when experiment finishes&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;当实验结束时，通知参与者平台（Sona Systems、Prolific 等）&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="369" />
        <source>JATOS: Configure the server</source>
        <translation>JATOS: 配置服务器</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="484" />
        <source>&lt;small  style="color:#78909c"&gt;JATOS is server software for managing online experiments. You need an account on a JATOS server, such as mindprobe.eu, to run experiments online. You need to enter a JATOS API token to connect OpenSesame to JATOS. Visit the OpenSesame documentation for instructions.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;JATOS 是用于管理在线实验的服务器软件。您需要在 JATOS 服务器（如 mindprobe.eu）上拥有一个帐户，才能在线运行实验。你需要输入一个 JATOS API 令牌以将 OpenSesame 连接到 JATOS。请访问 OpenSesame 文档以获取使用指南。&lt;/small&gt;</translation>
    </message>
</context>
</TS>