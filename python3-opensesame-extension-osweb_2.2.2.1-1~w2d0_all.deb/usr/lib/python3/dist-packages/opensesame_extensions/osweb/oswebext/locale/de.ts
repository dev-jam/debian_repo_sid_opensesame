<?xml version='1.0' encoding='utf-8'?>
<TS version="2.1">
<context>
    <name>extension_oswebext</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="28" />
        <source>Experiment started in external browser</source>
        <translation>Experiment in externem Browser gestartet</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="18" />
        <source>Save as…</source>
        <translation>Speichern unter..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="14" />
        <source>OSWeb and JATOS control panel</source>
        <translation>OSWeb und JATOS Kontrollpanel</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="17" />
        <source>Create online experiments</source>
        <translation>Online-Experimente erstellen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="20" />
        <source>Open from MindProbe</source>
        <translation>Öffnen von MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="13" />
        <source>Open from JATOS</source>
        <translation>Öffnen von JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="29" />
        <source>Open</source>
        <translation>Öffnen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="27" />
        <source>Experiment has been published to JATOS</source>
        <translation>Das Experiment wurde auf JATOS veröffentlicht</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="30" />
        <source>Select OSWeb results file…</source>
        <translation>Wählen Sie die OSWeb-Ergebnisdatei aus..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="25" />
        <source>Browse</source>
        <translation>Durchsuchen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="16" />
        <source>You have changed the name of the experiment. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Sie haben den Namen des Experiments geändert. Möchten Sie auch die Verbindung zum JATOS aufheben (indem Sie die UUID zurücksetzen), damit Sie ein neues Remote-Experiment erstellen können?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="15" />
        <source>Save and publish to JATOS</source>
        <translation>Speichern und veröffentlichen zu JATOS</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="19" />
        <source>Unlink from JATOS</source>
        <translation>Von JATOS trennen</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="22" />
        <source>Save and publish to MindProbe</source>
        <translation>Speichern und veröffentlichen zu MindProbe</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="24" />
        <source>You have saved the experiment under a different file name. Do you also want to unlink the experiment from JATOS (by resetting the UUID) so that you can create a new remote experiment?</source>
        <translation>Sie haben das Experiment unter einem anderen Dateinamen gespeichert. Möchten Sie das Experiment auch von JATOS trennen (durch Zurücksetzen der UUID), um ein neues Remote-Experiment erstellen zu können?</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="21" />
        <source>Downloading …</source>
        <translation>Herunterladen ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="23" />
        <source>Uploading …</source>
        <translation>Hochladen ..</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="26" />
        <source>Hide</source>
        <translation>Verstecken</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="31" />
        <source>Please wait …</source>
        <translation>Bitte warten ..</translation>
    </message>
</context>
<context>
    <name>osweb_control_panel</name>
    <message>
        <location filename="../osweb_control_panel.ui" line="14" />
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="65" />
        <source>ICON</source>
        <translation>ICON</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="136" />
        <source>Actions</source>
        <translation>Aktionen</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="181" />
        <source>Experiment properties</source>
        <translation>Eigenschaften des Experiments</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="199" />
        <source>&lt;small  style="color:#78909c"&gt;Select OSWeb backend to run in browser&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Wähle OSWeb-Backend, um im Browser auszuführen&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="215" />
        <source>Open from JATOS</source>
        <translation>Öffnen von JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="227" />
        <source>&lt;small  style="color:#78909c"&gt;Download experiment directly from JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Laden Sie das Experiment direkt von JATOS herunter&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="265" />
        <source>Convert OSWeb results to .csv/ .xlsx</source>
        <translation>Konvertiere OSWeb-Ergebnisse in .csv/ .xlsx</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="277" />
        <source>&lt;small  style="color:#78909c"&gt;Convert JATOS result file to spreadsheet format&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Konvertiere JATOS-Ergebnisdatei in Tabellenformat&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="305" />
        <source>Import from JATOS archive</source>
        <translation>Importieren aus dem JATOS-Archiv</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="318" />
        <source>Export to JATOS archive</source>
        <translation>Exportieren zum JATOS-Archiv</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="331" />
        <source>Export to HTML</source>
        <translation>Exportieren zu HTML</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="343" />
        <source>&lt;small  style="color:#78909c"&gt;Open experiment from jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Experiment aus jzip-Datei öffnen&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="355" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as jzip file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Speichern Sie das Experiment als jzip-Datei&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="367" />
        <source>&lt;small  style="color:#78909c"&gt;Save experiment as standalone html file&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Speichern Sie das Experiment als eigenständige HTML-Datei&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="78" />
        <source>&lt;b&gt;OSWeb and JATOS control panel&lt;/b&gt;&lt;br /&gt;Options for online experiments and JATOS synchronization</source>
        <translation>&lt;b&gt;OSWeb und JATOS Kontrollpanel&lt;/b&gt;&lt;br /&gt;Optionen für Online-Experimente und JATOS-Synchronisation</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="240" />
        <source>Save and publish to JATOS</source>
        <translation>Speichern und veröffentlichen zu JATOS</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="252" />
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Save experiment and upload directly to JATOS&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=" font-size:small; color:#78909c;"&gt;Speichern Sie das Experiment und laden Sie es direkt zu JATOS hoch&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../osweb_control_panel.ui" line="126" />
        <source>&lt;h2 style="color:#78909c"&gt;To publish experiments directly to JATOS, please specify a server and API token below&lt;/h2&gt;</source>
        <translation>&lt;h2 style="color:#78909c"&gt;Um Experimente direkt an JATOS zu veröffentlichen, geben Sie bitte unten einen Server und einen API-Token an&lt;/h2&gt;</translation>
    </message>
</context>
<context>
    <name>plugin_inline_html</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="4" />
        <source>Embeds custom HTML</source>
        <translation>Einbinden von individuell gestaltetem HTML</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="5" />
        <source>An HTML editor widget</source>
        <translation>Ein HTML-Editor-Widget</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="3" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="6" />
        <source>HTML editor</source>
        <translation>HTML-Editor</translation>
    </message>
</context>
<context>
    <name>plugin_inline_javascript</name>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="10" />
        <source>OSWeb</source>
        <translation>OSWeb</translation>
    </message>
    <message>
        <location filename="../../../../translation_tools/translatables.py" line="9" />
        <source>Executes JavaScript code</source>
        <translation>Führt JavaScript-Code aus</translation>
    </message>
</context>
<context>
    <name>preferences</name>
    <message>
        <location filename="../preferences.ui" line="14" />
        <source>Form</source>
        <translation>Formular</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="125" />
        <source>Possible subject numbers</source>
        <translation>Mögliche Versuchspersonennummern</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182" />
        <source>&lt;small  style="color:#78909c"&gt;Run experiment even if compatibility check fails&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Führen Sie das Experiment durch, auch wenn die Kompatibilitätsprüfung fehlschlägt&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="194" />
        <source>&lt;small style="color:#78909c"&gt;Appears on OSWeb welcome screen.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Erscheint auf dem Begrüßungsbildschirm von OSWeb.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103" />
        <source>Show OSWeb welcome screen</source>
        <translation>OSWeb-Begrüßungsbildschirm anzeigen</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="209" />
        <source>&lt;small  style="color:#78909c"&gt;Loaded when experiment starts&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Geladen, wenn das Experiment beginnt&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="135" />
        <source>Bypass compatibility check</source>
        <translation>Kompatibilitätsprüfung umgehen</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="142" />
        <source>Welcome text</source>
        <translation>Begrüßungstext</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="118" />
        <source>&lt;small  style="color:#78909c"&gt;Only applies when exporting&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Gilt nur beim Exportieren&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="84" />
        <source>Never provide personal or sensitive information such as credit card numbers or PIN codes. Click or touch the screen to begin!</source>
        <translation>Geben Sie niemals persönliche oder sensible Informationen wie Kreditkartennummern oder PIN-Codes an. Klicken oder berühren Sie den Bildschirm, um zu beginnen!</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="219" />
        <source>0,1</source>
        <translation>0,1</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="71" />
        <source>One URL per line</source>
        <translation>Eine URL pro Zeile</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="167" />
        <source>External libraries</source>
        <translation>Externe Bibliotheken</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="238" />
        <source>&lt;small  style="color:#78909c"&gt;Required for reliable media playback&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Erforderlich für zuverlässige Medienwiedergabe&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="226" />
        <source>Make browser fullscreen</source>
        <translation>Browser auf Vollbildmodus einstellen</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="305" />
        <source>JATOS UUID</source>
        <translation>JATOS UUID</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="415" />
        <source>&lt;small  style="color:#78909c"&gt;Visit &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; to request a free account&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Besuchen Sie &lt;a href="https://mindprobe.eu"&gt;mindprobe.eu&lt;/a&gt; um ein kostenloses Konto zu beantragen&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="387" />
        <source>JATOS server</source>
        <translation>JATOS-Server</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="435" />
        <source>jap_</source>
        <translation>jap_</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="403" />
        <source>https://jatos.mindprobe.eu</source>
        <translation>https://jatos.mindprobe.eu</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="330" />
        <source>&lt;small  style="color:#78909c"&gt;Identifies experiment on JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Identifiziert Experiment auf JATOS&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="318" />
        <source>undefined</source>
        <translation>undefiniert</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="422" />
        <source>JATOS API token</source>
        <translation>JATOS-API-Token</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="447" />
        <source>&lt;small  style="color:#78909c"&gt;Available from JATOS user profile&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Verfügbar aus dem JATOS-Benutzerprofil&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="337" />
        <source>Clear UUID</source>
        <translation>UUID löschen</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="353" />
        <source>&lt;small  style="color:#78909c"&gt;Resets link between experiment and JATOS&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Setzt die Verbindung zwischen Experiment und JATOS zurück&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245" />
        <source>Apply background color to full browser tab</source>
        <translation>Hintergrundfarbe auf den gesamten Browser-Tab anwenden</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="460" />
        <source>Ignore conflicts</source>
        <translation>Konflikte ignorieren</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="472" />
        <source>&lt;small  style="color:#78909c"&gt;Overwrites conflicting files when publishing. This option is automatically reset.&lt;/small&gt;</source>
        <translation>&lt;small style="color:#78909c"&gt;Überschreibt konfliktierende Dateien beim Veröffentlichen. Diese Option wird automatisch zurückgesetzt.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="41" />
        <source>OSWeb: Configure how the experiment runs in the browser</source>
        <translation>OSWeb: Konfigurieren Sie, wie das Experiment im Browser ausgeführt wird</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="157" />
        <source>&lt;small  style="color:#78909c"&gt;OSWeb is a JavaScript library for running OpenSesame experiments in a web browser.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;OSWeb ist eine JavaScript-Bibliothek zum Ausführen von OpenSesame-Experimenten in einem Webbrowser.&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="261" />
        <source>JATOS: Configure experiment properties on the server</source>
        <translation>JATOS: Konfigurieren Sie Experimenteigenschaften auf dem Server</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="279" />
        <source>JATOS end-redirect URL</source>
        <translation>JATOS End-Umleitungs-URL</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="286" />
        <source>https://</source>
        <translation>https://</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="298" />
        <source>&lt;small  style="color:#78909c"&gt;Notifies participant platform (Sona Systems, Prolific, etc.) when experiment finishes&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;Benachrichtigt die Teilnehmerplattform (Sona Systems, Prolific, usw.) wenn das Experiment beendet ist&lt;/small&gt;</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="369" />
        <source>JATOS: Configure the server</source>
        <translation>JATOS: Konfigurieren Sie den Server</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="484" />
        <source>&lt;small  style="color:#78909c"&gt;JATOS is server software for managing online experiments. You need an account on a JATOS server, such as mindprobe.eu, to run experiments online. You need to enter a JATOS API token to connect OpenSesame to JATOS. Visit the OpenSesame documentation for instructions.&lt;/small&gt;</source>
        <translation>&lt;small  style="color:#78909c"&gt;JATOS ist Server-Software für die Verwaltung von Online-Experimenten. Sie benötigen ein Konto auf einem JATOS-Server, wie mindprobe.eu, um Experimente online durchzuführen. Sie müssen ein JATOS-API-Token eingeben, um OpenSesame mit JATOS zu verbinden. Besuchen Sie die OpenSesame-Dokumentation für Anweisungen.&lt;/small&gt;</translation>
    </message>
</context>
</TS>