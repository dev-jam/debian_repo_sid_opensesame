"""Experiment Manager plugin for OpenSesame"""

# The name of the packages to check for updates on conda and pip
packages = ['opensesame-plugin-experiment-manager',
            'opensesame-plugin-experiment_manager']
