# These packages will be checked by the updater extension for updates on
# conda and pip
packages = ['opensesame-plugin-titta_eyetracking']
