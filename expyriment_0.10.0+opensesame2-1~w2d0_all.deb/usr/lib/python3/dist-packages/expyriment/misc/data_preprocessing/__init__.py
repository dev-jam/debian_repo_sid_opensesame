"""Data Preprocessing Module.

This module contains several classes and functions that help
to handle, preprocessing and aggregate Expyriment data files.

"""

__author__ = 'Florian Krause <florian@expyriment.org>, \
Oliver Lindemann <oliver@expyriment.org>'
__version__ = '0.10.0+opensesame2'
__revision__ = 'e925e44'
__date__ = 'Mon Dec 2 20:53:04 2019 +0100'


from ._data_preprocessing import read_datafile, get_experiment_duration
from ._data_preprocessing import write_csv_file, write_concatenated_data
from ._data_preprocessing import Aggregator
