"""
The statistics module.

This module contains miscellaneous stastistical functions for expyriment.

"""

__author__ = 'Florian Krause <florian@expyriment.org>, \
Oliver Lindemann <oliver@expyriment.org>'
__version__ = '0.10.0+opensesame2'
__revision__ = 'e925e44'
__date__ = 'Mon Dec 2 20:53:04 2019 +0100'


from ._statistics import sum, mode, mean, median, variance, std
from ._statistics import frequence_table, frequency_table
