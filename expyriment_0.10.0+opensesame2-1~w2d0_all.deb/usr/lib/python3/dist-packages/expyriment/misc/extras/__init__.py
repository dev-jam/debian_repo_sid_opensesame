"""
The misc extra package.

Notes
-----
    To us the extras module you have to import it manually by calling:
    `import expyriment.misc.extras`

"""

__author__ = 'Florian Krause <florian@expyriment.org> \
Oliver Lindemann <oliver@expyriment.org>'
__version__ = '0.10.0+opensesame2'
__revision__ = 'e925e44'
__date__ = 'Mon Dec 2 20:53:04 2019 +0100'


from ... import _internals

print("Misc plugins:")
for name, code in _internals.import_plugins_code("misc").items():
    print(" " + name)
    try:
        exec(code)
    except Exception as err:
        print("Warning: Could not import {0}".format(name))
        print(" {0}".format(err))

try:
    del (name, code)
except:
    pass