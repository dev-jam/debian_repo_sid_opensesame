"""Everything about video manipulation."""
